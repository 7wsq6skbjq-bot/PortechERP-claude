# Portech — PRD

## Problem statement (verbatim, itération initiale)
> "Je veux créé un site pour mon entreprise. Portech est une entreprise spécialisée dans l'installation de quincaillerie pour portes commerciales..."

## Itération 2 — mise à jour (user input verbatim)
> "Je veux que tu retire le fond blanc de mon Logo, assure toi qu'il est bien grand, gros et visible sur le site. Mon courriel pro est: portech.infos@gmail.com. je déserrverai tout le grand montréal. attention, je n'installe pas des portes, je ne fait qu'installer la quincailerie. Utilse les ton de bleu marine comme mon logo. Resend. Auth admin + dashboard. Plus d'images."

## Itération 3 — ajustements
> "Hero: 'Votre expert en quincaillerie de portes commerciales.' Admin login: plus de blanc/contraste, mélanger les tons."

## Architecture
- **Backend** : FastAPI + motor (MongoDB). Routes préfixées `/api`.
  - Public : `GET /` (health), `POST /contact`, `GET/POST /status`
  - Auth : `POST /auth/login`, `POST /auth/logout`, `GET /auth/me`
  - Admin (JWT requis) : `GET /admin/submissions`, `GET /admin/stats`, `DELETE /admin/submissions/{id}`
  - Intégrations : **Resend** (notification email leads) + **Nano Banana** (génération images hors-runtime)
- **Frontend** : React 19 + React Router 7 + Tailwind + lucide-react.
  - Public : Home, Services, About, Contact (Layout wrapper)
  - Admin : `/admin/login` + `/admin` (hors Layout, ProtectedRoute)
  - AuthContext avec localStorage token fallback (cross-origin)
- **MongoDB** : `contact_submissions`, `admin_users`, `status_checks`

## User personas
- Gestionnaires d'immeubles / syndics (tours à condos)
- Directeurs de commerce, restaurant, épicerie, boulangerie
- Directeurs d'écoles / institutions
- Entrepreneurs généraux cherchant un sous-traitant quincaillerie

## Core requirements
- Site lead-gen avec CTA "Demander une soumission" répétés
- Clarifier : Portech = **quincaillerie uniquement** (pas installation de portes — c'est le vitrier)
- 4 pages SEO + formulaire contact + dashboard admin
- Palette **bleu marine** cohérente avec le logo
- Service : **Grand Montréal**

## What's been implemented

### 2026-01 — MVP (iter 1)
- 4 pages publiques, formulaire contact, design industriel monochrome + bleu
- Backend + MongoDB, 100% tests réussis

### 2026-01 — Iter 2
- **Logo Portech** avec fond transparent (PNG, +version blanche pour fonds sombres), affiché grand dans le nav et le footer
- **Copywriting repositionné** — accent sur "quincaillerie" partout ; nouvelle section "Notre périmètre" sur la page Services qui clarifie que Portech ne pose pas les portes elles-mêmes (vitrier)
- **Palette bleu marine** (10 teintes navy #0c182b → #f3f6fb) remplace le monochrome + accent bleu
- **Coordonnées** : `portech.infos@gmail.com` + `Grand Montréal` dans footer, page Contact, métadonnées
- **Resend** intégré — chaque soumission du formulaire envoie un email HTML formaté à `portech.infos@gmail.com` (sender `onboarding@resend.dev`, reply-to = email du lead). Fallback : si Resend échoue, la soumission est quand même sauvée.
- **Auth JWT admin** : bcrypt + JWT (HS256, 8h), seed au startup depuis env, cookie httpOnly + bearer fallback
- **Dashboard admin** (`/admin`) : stats (total, 30j, emails envoyés), tableau recherchable, détail en drawer avec bouton Répondre (mailto préformaté) + Supprimer
- **14 images générées** via Gemini Nano Banana (barres antipaniques, ferme-portes, serrures, techniciens, avant/après, corridor école, lobby condo, etc.) — servies depuis `/public/generated/`
- **Tests** : backend 100% (20/20 pytest), frontend 100%, Resend live confirmé

### 2026-01 — Iter 3
- Hero title → "Votre expert en quincaillerie de portes commerciales."
- Page admin login redesignée en split 42/58 (panneau bleu branding + panneau blanc form) — beaucoup plus de contraste

## Backlog / P1
- [ ] Vérifier / acheter un domaine (portech.ca ?) et le connecter à Resend pour envoyer à n'importe quelle adresse
- [ ] Photos avant/après réelles (remplacer les placeholders IA)
- [ ] Numéro de téléphone lorsque disponible
- [ ] Restreindre `CORS_ORIGINS` au domaine de prod
- [ ] Page mentions légales + politique de confidentialité

## Backlog / P2
- [ ] Notification SMS Twilio en plus du courriel (alerte lead <30s)
- [ ] Blog SEO (barres antipaniques, codes du bâtiment QC)
- [ ] Upload de photos dans le formulaire de contact
- [ ] Export CSV des soumissions depuis le dashboard
- [ ] Calendrier des rendez-vous / intégration Google Calendar

## Key URLs
- Site : `https://web-project-fr-2.preview.emergentagent.com`
- Admin : `https://web-project-fr-2.preview.emergentagent.com/admin/login`
- Identifiants : voir `/app/memory/test_credentials.md`

## Notes techniques
- Resend en mode test : les emails ne partent qu'à l'adresse du compte Resend (sauf domaine vérifié). Pour envoyer librement à portech.infos@gmail.com, le compte Resend doit être créé avec cette adresse OU un domaine doit être vérifié.
- Script de régénération d'images : `python3 /app/scripts/generate_images.py` (idempotent, écrase les PNGs existants).
